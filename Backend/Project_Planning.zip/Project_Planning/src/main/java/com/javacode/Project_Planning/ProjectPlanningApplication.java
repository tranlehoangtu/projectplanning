package com.javacode.Project_Planning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectPlanningApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectPlanningApplication.class, args);
	}

}
