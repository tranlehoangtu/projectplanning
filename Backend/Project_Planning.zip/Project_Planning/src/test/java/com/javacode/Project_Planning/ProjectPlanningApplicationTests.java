package com.javacode.Project_Planning;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectPlanningApplicationTests {

	@Test
	void contextLoads() {
	}

}
